willow
======

Willow is a flexible platform for managing pen and paper, LARP and by-mail role-playing games.
