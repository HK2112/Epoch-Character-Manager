# Reserved for character generation helpers
